This package contains typings of coc.nvim only.

Files were exported from https://github.com/neoclide/coc.nvim/blob/master/typings

## Installation

    npm install --save-dev coc.nvim

## Support coc.nvim

If you like my work, consider supporting me on Patreon or PayPal:

<a href="https://www.patreon.com/chemzqm"><img src="https://c5.patreon.com/external/logo/become_a_patron_button.png" alt="Patreon donate button" /> </a>
<a href="https://www.paypal.com/paypalme/chezqm"><img src="https://werwolv.net/assets/paypal_banner.png" alt="PayPal donate button" /> </a>

## Credits

[Visual Studio Code](https://github.com/microsoft/vscode), and [Microsoft](https://github.com/microsoft)
